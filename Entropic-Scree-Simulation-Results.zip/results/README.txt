ENTROPIC SCREE: SAVED SIMULATION RESULTS

These files accompany the two simulation scripts in the Entropic-Scree GitHub
repository and the methods paper: https://doi.org/10.5281/zenodo.22028086

All numerical files are unchanged copies of saved study outputs. This export
does not rerun the simulations or substitute results from a newer package.
The reported experiments used Entropic.Scree 1.0.1.

REPLICATED STUDY: results/replicated-study/

Experiment identifier: cbc6a0b3f0ca.
Executed settings: N = 5,000 observations; m = 10,000 retained measurements;
50% continuous and 50% binary; generating counts 6 through 26; orthogonal,
low-entanglement and high-entanglement conditions; 20 seeds per configuration.
There are 1,260 completed runs and 63 configuration summaries.

Start with:
  SEED-RESULTS.csv                 One row per completed run, including seeds,
                                  dimensions, ranks and spectral summaries.
  RANK-SUMMARY.csv                 Results by generating count and condition.
  RANK-SUMMARY-COMPACT.csv          Compact configuration-level results.
  RANK-SUMMARY.txt                 Readable summary and interpretation notes.
  GENERATING-DIMENSION-CONTEXT.csv Generating and observed dimensional summaries.
  replicated-rank-recovery.png     Four-panel figure used for the paper.
  replicated-rank-recovery.pdf     Vector version of that figure.

CONFIGURATIONS.csv records the job grid and seeds. SETTINGS.txt and SETTINGS.rds
record executed settings; CRAN-AND-MATH-PROVENANCE.rds and MATH-BACKEND.txt record
software and numerical-backend provenance. SEED-RESULTS.rds supplies the same
per-run result collection in native R format.

The historical output-directory label contains N10000-M20000. The executed
settings and result rows establish N5000-M10000 for this study. Historical paths
inside saved settings are provenance, not required installation locations.

SINGLE-RUN COMPARISONS AND ABLATION: results/single-run-comparisons/

The three condition folders identify their seeds:
  orthogonal: 19862026
  low entanglement: 19862027
  high entanglement: 19862029

These are the first-seed r = 20 cases from the replicated study, not three
additional independent replications. Each condition compares standard PCA,
rank PCA, RBF kernel PCA and Entropic Scree using the same observations.

COMPARISON-SUMMARY.csv contains method results. DIMENSION-CONTEXT.csv records
generating-dimension diagnostics. SPECTRUM-*.csv files contain saved spectra.
SETTINGS.*, GENERATION-SUMMARY.rds and sessionInfo.txt preserve provenance.
Native R result objects and the generated PNG/PDF figures are also included.

The orthogonal folder additionally contains:
  ABLATION-RESULTS.csv          Full numerical results for all three bin targets.
  ABLATION-TABLE.tex            Generated LaTeX summary.
  Ablation_Broad_And_Zoom.*    Broad and early-region spectrum figure for the paper.
  BIN-TARGETS.rds               Bin-target definitions and sampled-column details.
  FD-TARGET-SAMPLE.csv          Measurements used for the FD-derived target.
  FSIG-*.csv                    Axis-specific gravity values for each target.
  RETAINED-*.csv                Retained measurement identities.

Bin targets 18, 71 and 146 selected primary boundaries 20, 20 and 5019, with
extended boundaries 173, 50 and 5051. The 146-bin value is the automatic result;
no visual override was substituted. Alternative figure views remain available
with their original filenames.

INTERPRETATION AND FILE SCOPE

CSV column names are preserved from the study software. root_effective_rank
describes the population generating-correlation spectrum; expanded_effective_rank
describes the active expansion design; R_eff describes the observed working
information spectrum. They are distinct quantities. Baseline threshold counts
are not automatically fitted visual elbows.

Empty fields remain empty; they have not been replaced with zeros. In particular,
the replicated SEED-RESULTS.csv does not supply values in its SCDR and mean_trace
columns. VISUAL-ASSESSMENT.csv files are blank optional review forms, not observed
visual-assessment results.

This publication export contains the complete replicated per-run summary, its
configuration-level summaries, and the saved numerical outputs and figures for
the three single-run comparisons and ablation. It omits the 1,260 individual
replicated-fit folders (per-run spectra, result objects, plots and execution
logs), installed R libraries, worker logs and completion markers. It is not a
complete resumable working-directory archive. Raw generated datasets and
centered matrices were not retained as permanent study outputs; the simulation
scripts specify regeneration.

INTEGRITY

FILE-HASHES.json lists each copied file's relative path, byte size and SHA-256.
All copied files were checked against their source bytes. The principal
replicated results and settings also match the saved manuscript audit.
